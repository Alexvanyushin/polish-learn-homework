class PolishVocabApp {
    constructor() {
        this.vocabulary = [];
        this.phraseIds = []; // Store phrase IDs for progress tracking
        this.currentIndex = 0;
        this.showingWord = true;
        this.shuffledIndices = [];
        this.modes = [];
        this.selectedMode = null;
        this.selectedTopic = null;
        this.topicProgress = { learned_count: 0, total_count: 0 }; // Progress for current topic
        this.hardPhrases = []; // Store hard phrases for review
        this.isHardPhrasesMode = false; // Track if we're in hard phrases review mode
        this.hardPhrasesCount = 0; // Count of hard phrases

        // Language state - default to 'ru' as per requirement
        const savedLanguage = localStorage.getItem('language');
        this.currentLanguage = savedLanguage || 'ru';

        // UI Elements
        this.loadingEl = document.getElementById('loading');
        this.modeSelectionEl = document.getElementById('mode-selection');
        this.topicSelectionEl = document.getElementById('topic-selection');
        this.appEl = document.getElementById('app');
        this.completionEl = document.getElementById('completion');
        this.wordDisplayEl = document.getElementById('word-display');
        this.phraseDisplayEl = document.getElementById('phrase-display');
        this.progressTextEl = document.getElementById('progress-text');
        this.modeButtonsEl = document.getElementById('mode-buttons');
        this.topicButtonsEl = document.getElementById('topic-buttons');
        this.topicTitleEl = document.getElementById('topic-title');
        this.backToModesBtn = document.getElementById('back-to-modes');
        this.backToTopicsBtn = document.getElementById('back-to-topics');
        this.restartBtn = document.getElementById('restart-btn');
        this.copyWordBtn = document.getElementById('copy-word-btn');
        this.copyWordBtnMobile = document.getElementById('copy-word-btn-mobile');
        this.copyPhraseBtn = document.getElementById('copy-phrase-btn');
        this.playAudioBtn = document.getElementById('play-audio-btn');
        this.phraseContainerEl = document.querySelector('.phrase-container');
        this.phraseActionsEl = document.querySelector('.phrase-actions');
        this.resetProgressBtn = document.getElementById('reset-progress-btn');
        this.backPhraseBtn = document.getElementById('back-phrase-btn');
        this.saveHardPhraseBtn = document.getElementById('save-hard-phrase-btn');
        this.nowOkBtn = document.getElementById('now-ok-btn');
        this.repeatHardPhrasesBtn = document.getElementById('repeat-hard-phrases-btn');
        this.hardPhrasesCountEl = document.getElementById('hard-phrases-count');
        this.noHardPhrasesEl = document.getElementById('no-hard-phrases');
        this.backFromNoHardBtn = document.getElementById('back-from-no-hard');

        // Language switcher buttons
        this.langBtnEn = document.getElementById('lang-btn-en');
        this.langBtnRu = document.getElementById('lang-btn-ru');
        this.langBtnEnApp = document.getElementById('lang-btn-en-app');
        this.langBtnRuApp = document.getElementById('lang-btn-ru-app');

        // Create audio element for playing MP3 (will be set dynamically)
        this.audioElement = new Audio();

        // Add event listeners for audio play/pause to update button icon
        this.audioElement.addEventListener('play', () => {
            this.updatePlayButtonIcon(true);
        });

        this.audioElement.addEventListener('pause', () => {
            this.updatePlayButtonIcon(false);
        });

        this.audioElement.addEventListener('ended', () => {
            this.updatePlayButtonIcon(false);
        });

        // Initialize language switcher UI
        this.updateLanguageSwitcherUI();

        this.init();
    }

    updateLanguageSwitcherUI() {
        // Update all language switcher buttons
        const allLangBtns = [
            this.langBtnEn,
            this.langBtnRu,
            this.langBtnEnApp,
            this.langBtnRuApp
        ];

        allLangBtns.forEach(btn => {
            if (btn) {
                if (btn.dataset.lang === this.currentLanguage) {
                    btn.classList.add('active');
                } else {
                    btn.classList.remove('active');
                }
            }
        });
    }

    switchLanguage(lang) {
        if (lang === this.currentLanguage) {
            return; // Already selected
        }

        this.currentLanguage = lang;
        localStorage.setItem('language', lang);
        this.updateLanguageSwitcherUI();

        // Refresh current view to show content in new language
        if (!this.modeSelectionEl.classList.contains('hidden')) {
            this.showModeSelection();
        } else if (!this.topicSelectionEl.classList.contains('hidden')) {
            if (this.selectedMode) {
                this.showTopicSelection(this.selectedMode);
            }
        } else if (!this.appEl.classList.contains('hidden')) {
            // Refresh current word/phrase display
            if (this.showingWord) {
                this.showCurrentWord();
            } else {
                this.showCurrentPhrase();
            }
        }
    }

    async init() {
        try {
            await this.loadModes();
            this.setupEventListeners();
            await this.loadHardPhrasesCount();
            this.showModeSelection();
        } catch (error) {
            console.error('Failed to initialize app:', error);
            this.showError('Failed to load vocabulary. Please refresh the page.');
        }
    }

    async resetProgress() {
        // Show confirmation dialog
        const confirmed = confirm(
            'Are you sure you want to reset all your progress?\n\n' +
            'This will delete all learned phrases across all courses and topics. ' +
            'This action cannot be undone.'
        );

        if (!confirmed) {
            return;
        }

        try {
            const response = await fetch('/api/progress/reset', {
                method: 'DELETE'
            });

            if (!response.ok) {
                throw new Error('Failed to reset progress');
            }

            const data = await response.json();
            alert(`Progress reset successfully!\n\n${data.deleted_count} records deleted.`);

            // Reload courses to refresh progress display
            await this.showModeSelection();
        } catch (error) {
            console.error('Failed to reset progress:', error);
            alert('Failed to reset progress. Please try again.');
        }
    }

    async resetModeProgress(modeId, modeName) {
        // Show confirmation dialog
        const confirmed = confirm(
            `Are you sure you want to reset progress for "${modeName}"?\n\n` +
            'This will delete all learned phrases in this course. ' +
            'This action cannot be undone.'
        );

        if (!confirmed) {
            return;
        }

        try {
            const params = new URLSearchParams({ mode_id: modeId });
            const response = await fetch(`/api/progress/reset-mode?${params}`, {
                method: 'DELETE'
            });

            if (!response.ok) {
                throw new Error('Failed to reset mode progress');
            }

            const data = await response.json();
            alert(`Progress reset successfully!\n\n${data.deleted_count} records deleted.`);

            // Reload courses to refresh progress display
            await this.showModeSelection();
        } catch (error) {
            console.error('Failed to reset mode progress:', error);
            alert('Failed to reset progress. Please try again.');
        }
    }

    async resetTopicProgress(modeId, topicName) {
        // Show confirmation dialog
        const confirmed = confirm(
            `Are you sure you want to reset progress for "${topicName}"?\n\n` +
            'This will delete all learned phrases in this topic. ' +
            'This action cannot be undone.'
        );

        if (!confirmed) {
            return;
        }

        try {
            const params = new URLSearchParams({
                mode_id: modeId,
                topic_name: topicName
            });
            const response = await fetch(`/api/progress/reset-topic?${params}`, {
                method: 'DELETE'
            });

            if (!response.ok) {
                throw new Error('Failed to reset topic progress');
            }

            const data = await response.json();
            alert(`Progress reset successfully!\n\n${data.deleted_count} records deleted.`);

            // Reload topic selection to refresh progress display
            if (this.selectedMode) {
                await this.showTopicSelection(this.selectedMode);
            }
        } catch (error) {
            console.error('Failed to reset topic progress:', error);
            alert('Failed to reset progress. Please try again.');
        }
    }

    async loadModes() {
        const response = await fetch('/api/modes');
        if (!response.ok) {
            throw new Error('Failed to fetch courses');
        }

        const data = await response.json();
        this.modes = data.modes;

        if (this.modes.length === 0) {
            throw new Error('No courses available');
        }
    }

    setupEventListeners() {
        // Reset progress button
        this.resetProgressBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            this.resetProgress();
        });

        // Navigation buttons
        this.backToModesBtn.addEventListener('click', async (e) => {
            e.stopPropagation();
            await this.showModeSelection();
        });

        this.backToTopicsBtn.addEventListener('click', async (e) => {
            e.stopPropagation();
            if (this.isHardPhrasesMode) {
                // From hard phrases mode, go back to mode selection
                await this.showModeSelection();
            } else if (this.selectedMode && this.selectedMode.type === 'topics') {
                this.showTopicSelection(this.selectedMode);
            } else {
                await this.showModeSelection();
            }
        });

        this.restartBtn.addEventListener('click', async (e) => {
            e.stopPropagation();
            await this.showModeSelection();
        });

        // Copy buttons
        this.copyWordBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            this.copyToClipboard(this.wordDisplayEl.textContent, 'Russian text');
        });

        this.copyWordBtnMobile.addEventListener('click', (e) => {
            e.stopPropagation();
            this.copyToClipboard(this.wordDisplayEl.textContent, 'Russian text');
        });

        this.copyPhraseBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            this.copyToClipboard(this.phraseDisplayEl.textContent, 'Polish text');
        });

        // Play audio button
        this.playAudioBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            this.playAudio();
        });

        // Back phrase button (mobile)
        this.backPhraseBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            this.goToPreviousWord();
        });

        // Save hard phrase button
        this.saveHardPhraseBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            this.saveHardPhrase();
        });

        // Now Ok button (remove from hard phrases)
        this.nowOkBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            this.removeHardPhrase();
        });

        // Repeat hard phrases button
        this.repeatHardPhrasesBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            this.startHardPhrasesReview();
        });

        // Back from no hard phrases
        this.backFromNoHardBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            this.showModeSelection();
        });

        // Language switcher buttons
        if (this.langBtnEn) {
            this.langBtnEn.addEventListener('click', (e) => {
                e.stopPropagation();
                this.switchLanguage('en');
            });
        }
        if (this.langBtnRu) {
            this.langBtnRu.addEventListener('click', (e) => {
                e.stopPropagation();
                this.switchLanguage('ru');
            });
        }
        if (this.langBtnEnApp) {
            this.langBtnEnApp.addEventListener('click', (e) => {
                e.stopPropagation();
                this.switchLanguage('en');
            });
        }
        if (this.langBtnRuApp) {
            this.langBtnRuApp.addEventListener('click', (e) => {
                e.stopPropagation();
                this.switchLanguage('ru');
            });
        }

        // Spacebar and arrow keys (only during training)
        document.addEventListener('keydown', (e) => {
            if (!this.appEl.classList.contains('hidden')) {
                if (e.code === 'Space') {
                    e.preventDefault();
                    this.handleNext();
                } else if (e.code === 'ArrowLeft') {
                    e.preventDefault();
                    this.goToPreviousWord();
                }
            }
        });

        // Click handler (only during training)
        document.addEventListener('click', (e) => {
            // Only handle clicks in the training view
            if (!this.appEl.classList.contains('hidden')) {
                // Don't handle clicks on buttons
                if (!e.target.closest('button')) {
                    this.handleNext();
                }
            }
        });
    }

    async showModeSelection() {
        // Hide all views
        this.loadingEl.classList.add('hidden');
        this.topicSelectionEl.classList.add('hidden');
        this.appEl.classList.add('hidden');
        this.completionEl.classList.add('hidden');
        this.noHardPhrasesEl.classList.add('hidden');

        // Reset hard phrases mode
        this.isHardPhrasesMode = false;

        // Reload modes from server to get fresh progress data
        try {
            await this.loadModes();
        } catch (error) {
            console.error('Failed to reload modes:', error);
            // Continue with existing modes data if reload fails
        }

        // Reload hard phrases count
        await this.loadHardPhrasesCount();

        // Show mode selection
        this.modeSelectionEl.classList.remove('hidden');

        // Render mode buttons with progress
        this.modeButtonsEl.innerHTML = '';
        this.modes.forEach(mode => {
            const buttonContainer = document.createElement('div');
            buttonContainer.className = 'mode-btn-container';

            const button = document.createElement('button');
            button.className = 'mode-btn';

            // Build button content
            const modeName = document.createElement('div');
            modeName.className = 'mode-name';
            modeName.textContent = mode.name;

            const modeProgress = document.createElement('div');
            modeProgress.className = 'mode-progress';

            if (mode.progress && mode.progress.total_count > 0) {
                const learned = mode.progress.learned_count;
                const total = mode.progress.total_count;
                const remaining = total - learned;

                // Calculate percentage
                const percentage = Math.round((learned / total) * 100);

                // Determine status for color coding
                let statusClass = '';
                if (learned === 0) {
                    statusClass = 'not-learned';
                } else if (learned === total) {
                    statusClass = 'done';
                } else {
                    statusClass = 'in-progress';
                }

                modeProgress.innerHTML = `
                    <span class="progress-status ${statusClass}">${percentage}% learned</span>
                    ${total > 0 ? ` • ${learned}/${total}` : ''}
                `;
            } else {
                modeProgress.textContent = 'No progress data';
            }

            button.appendChild(modeName);
            button.appendChild(modeProgress);
            button.addEventListener('click', () => this.selectMode(mode));

            buttonContainer.appendChild(button);

            // Add reset button only if there's progress
            const hasProgress = mode.progress && mode.progress.learned_count > 0;
            if (hasProgress) {
                const resetBtn = document.createElement('button');
                resetBtn.className = 'reset-mode-btn';
                resetBtn.textContent = '↻';
                resetBtn.title = `Reset progress for ${mode.name}`;
                resetBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    this.resetModeProgress(mode.id, mode.name);
                });
                buttonContainer.appendChild(resetBtn);
            }

            this.modeButtonsEl.appendChild(buttonContainer);
        });
    }

    selectMode(mode) {
        this.selectedMode = mode;

        if (mode.type === 'simple') {
            // Load phrases directly and start training
            this.loadSimpleModeVocabulary(mode);
        } else {
            // Show topic selection
            this.showTopicSelection(mode);
        }
    }

    async loadSimpleModeVocabulary(mode) {
        try {
            this.loadingEl.classList.remove('hidden');
            this.modeSelectionEl.classList.add('hidden');

            const response = await fetch(`/api/phrases/${mode.id}`);
            if (!response.ok) {
                throw new Error('Failed to fetch phrases');
            }

            const phrases = await response.json();
            this.vocabulary = this.convertToVocabulary(phrases, mode.type);
            this.prepareTraining();
        } catch (error) {
            console.error('Failed to load vocabulary:', error);
            this.showError('Failed to load vocabulary. Please try again.');
        }
    }

    async showTopicSelection(mode) {
        // Hide all views
        this.loadingEl.classList.add('hidden');
        this.modeSelectionEl.classList.add('hidden');
        this.appEl.classList.add('hidden');
        this.completionEl.classList.add('hidden');

        // Show topic selection
        this.topicSelectionEl.classList.remove('hidden');
        this.topicTitleEl.textContent = `Select Topic - ${mode.name}`;

        // Render topic buttons with progress
        this.topicButtonsEl.innerHTML = '';

        // Fetch progress for all topics
        const topicsWithProgress = await Promise.all(
            mode.topics.map(async (topic) => {
                try {
                    const params = new URLSearchParams({
                        mode_id: mode.id,
                        topic_name: topic.name
                    });
                    const response = await fetch(`/api/progress?${params}`);
                    if (response.ok) {
                        const progress = await response.json();
                        return { ...topic, progress };
                    }
                } catch (error) {
                    console.error(`Failed to load progress for topic ${topic.name}:`, error);
                }
                return { ...topic, progress: { learned_count: 0, total_count: topic.count } };
            })
        );

        topicsWithProgress.forEach(topic => {
            const buttonContainer = document.createElement('div');
            buttonContainer.className = 'topic-btn-container';

            const button = document.createElement('button');
            button.className = 'topic-btn';
            const progressText = topic.progress
                ? `${topic.progress.learned_count} / ${topic.progress.total_count} learned`
                : `${topic.count} phrases`;

            // Determine progress status
            let statusClass = '';
            if (topic.progress) {
                if (topic.progress.learned_count === 0) {
                    statusClass = 'not-learned';
                } else if (topic.progress.learned_count === topic.progress.total_count) {
                    statusClass = 'done';
                } else {
                    statusClass = 'in-progress';
                }
            }

            button.innerHTML = `
                <div class="topic-name">${topic.name}</div>
                <div class="topic-count">
                    ${topic.count} phrases •
                    <span class="progress-status ${statusClass}">${progressText}</span>
                </div>
            `;
            button.addEventListener('click', () => this.selectTopic(topic.name));

            buttonContainer.appendChild(button);

            // Add reset button only if there's progress
            const hasProgress = topic.progress && topic.progress.learned_count > 0;
            if (hasProgress) {
                const resetBtn = document.createElement('button');
                resetBtn.className = 'reset-topic-btn';
                resetBtn.textContent = '↻';
                resetBtn.title = `Reset progress for ${topic.name}`;
                resetBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    this.resetTopicProgress(mode.id, topic.name);
                });
                buttonContainer.appendChild(resetBtn);
            }

            this.topicButtonsEl.appendChild(buttonContainer);
        });
    }

    async selectTopic(topicName) {
        this.selectedTopic = topicName;

        try {
            this.loadingEl.classList.remove('hidden');
            this.topicSelectionEl.classList.add('hidden');

            const params = new URLSearchParams({
                mode_id: this.selectedMode.id,
                topic_name: topicName
            });
            const response = await fetch(`/api/topic-phrases?${params}`);
            if (!response.ok) {
                throw new Error('Failed to fetch topic phrases');
            }

            const data = await response.json();
            const phrases = data.phrases || data; // Support both old and new format
            this.topicProgress = data.progress || { learned_count: 0, total_count: phrases.length };

            // Store phrase IDs for progress tracking
            this.phraseIds = phrases.map(p => p.id || null).filter(id => id !== null);

            this.vocabulary = this.convertToVocabulary(phrases, this.selectedMode.type);
            this.prepareTraining();
        } catch (error) {
            console.error('Failed to load topic phrases:', error);
            this.showError('Failed to load phrases. Please try again.');
        }
    }

    convertToVocabulary(phrases, type) {
        if (type === 'simple') {
            // phrases.txt format: { word, phrase }
            return phrases;
        } else {
            // JSON format: { ru, en, pl, id, audio }
            // Preserve both ru and en fields for language switching
            return phrases.map(p => ({
                word: p.en || p.ru, // Default word (for backward compatibility)
                ru: p.ru || null,
                en: p.en || null,
                phrase: p.pl,
                id: p.id || null,
                audio: p.audio || null,
                mode_id: p.mode_id || null
            }));
        }
    }

    prepareTraining() {
        if (this.vocabulary.length === 0) {
            this.showError('No phrases available for this selection.');
            return;
        }

        // Create shuffled indices for random order
        this.shuffledIndices = Array.from({ length: this.vocabulary.length }, (_, i) => i);
        this.shuffleArray(this.shuffledIndices);

        // Reset training state
        this.currentIndex = 0;
        this.showingWord = true;

        // Always show back button - goes to topics or mode selection
        this.backToTopicsBtn.classList.remove('hidden');

        // Start training
        this.startApp();
    }

    shuffleArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
    }

    startApp() {
        this.loadingEl.classList.add('hidden');
        this.appEl.classList.remove('hidden');
        this.showCurrentWord();
    }

    showCurrentWord() {
        const currentVocab = this.vocabulary[this.shuffledIndices[this.currentIndex]];

        // Display word based on selected language
        let displayWord;
        if (this.currentLanguage === 'en') {
            displayWord = currentVocab.en || currentVocab.ru || currentVocab.word;
        } else {
            displayWord = currentVocab.ru || currentVocab.word;
        }

        this.wordDisplayEl.textContent = displayWord;
        this.phraseDisplayEl.textContent = currentVocab.phrase;

        // Reset audio and button state when showing new word
        this.audioElement.pause();
        this.audioElement.currentTime = 0;
        this.updatePlayButtonIcon(false);

        // Show only word, hide phrase
        this.wordDisplayEl.classList.remove('hidden');
        this.phraseDisplayEl.classList.add('hidden');
        this.phraseContainerEl.classList.add('hidden');
        this.phraseActionsEl.classList.add('hidden');

        // Show copy button for word, hide play and copy buttons for phrase
        this.copyWordBtn.classList.remove('hidden');
        this.copyWordBtnMobile.classList.remove('hidden');
        this.copyPhraseBtn.classList.add('hidden');
        this.playAudioBtn.classList.add('hidden');

        this.showingWord = true;
        this.updateProgress();
    }

    showCurrentPhrase() {
        // Show both word and phrase
        this.wordDisplayEl.classList.remove('hidden');
        this.phraseDisplayEl.classList.remove('hidden');
        this.phraseContainerEl.classList.remove('hidden');

        // Show copy buttons for both
        this.copyWordBtn.classList.remove('hidden');
        this.copyWordBtnMobile.classList.remove('hidden');
        this.copyPhraseBtn.classList.remove('hidden');

        // Show play button only if current phrase has audio
        const currentVocab = this.vocabulary[this.shuffledIndices[this.currentIndex]];
        if (currentVocab.audio) {
            this.playAudioBtn.classList.remove('hidden');
        } else {
            this.playAudioBtn.classList.add('hidden');
        }

        // Show phrase actions container and appropriate button
        this.phraseActionsEl.classList.remove('hidden');

        // Show "Save for later" button in normal mode, "Now Ok" button in hard phrases mode
        if (this.isHardPhrasesMode) {
            this.saveHardPhraseBtn.classList.add('hidden');
            this.nowOkBtn.classList.remove('hidden');
        } else {
            // Only show "Save for later" if we're in a topic-based mode with a valid phrase ID
            if (this.selectedMode && this.selectedTopic && currentVocab.id) {
                this.saveHardPhraseBtn.classList.remove('hidden');
            } else {
                this.saveHardPhraseBtn.classList.add('hidden');
            }
            this.nowOkBtn.classList.add('hidden');
        }

        this.showingWord = false;
    }

    goToPreviousWord() {
        if (this.currentIndex > 0) {
            this.currentIndex--;
            this.showCurrentWord();
        }
    }

    handleNext() {
        if (this.showingWord) {
            // Currently showing word, show phrase
            this.showCurrentPhrase();
        } else {
            // Currently showing phrase, move to next word
            // Mark current phrase as learned before moving to next (only in normal mode)
            if (!this.isHardPhrasesMode) {
                this.markCurrentPhraseAsLearned();
            }

            this.currentIndex++;

            if (this.currentIndex >= this.vocabulary.length) {
                // All words completed
                if (this.isHardPhrasesMode) {
                    // In hard phrases mode, show completion or go back
                    this.showCompletion();
                } else {
                    this.showCompletion();
                }
            } else {
                this.showCurrentWord();
            }
        }
    }

    async markCurrentPhraseAsLearned() {
        if (!this.selectedMode || !this.selectedTopic) {
            return; // Not in a topic-based mode
        }

        const currentVocab = this.vocabulary[this.shuffledIndices[this.currentIndex]];
        const phrazeId = currentVocab.id;

        if (!phrazeId) {
            return; // No ID available for this phrase
        }

        try {
            await fetch('/api/progress', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    mode_id: this.selectedMode.id,
                    phraze_id: phrazeId
                })
            });

            // Update local progress count (optimistic update)
            // Note: We increment assuming it wasn't already learned
            // The backend handles duplicates correctly
            if (this.topicProgress.total_count > 0) {
                // Only increment if we haven't reached the total yet
                if (this.topicProgress.learned_count < this.topicProgress.total_count) {
                    this.topicProgress.learned_count++;
                }
            }
        } catch (error) {
            console.error('Failed to mark progress:', error);
            // Don't show error to user, just log it
        }
    }

    updateProgress() {
        // Only show current position, not learned progress
        this.progressTextEl.textContent = `${this.currentIndex + 1} / ${this.vocabulary.length}`;
    }

    showCompletion() {
        if (this.isHardPhrasesMode) {
            // In hard phrases mode, go back to mode selection when done
            this.showModeSelection();
        } else {
            this.appEl.classList.add('hidden');
            this.completionEl.classList.remove('hidden');
        }
    }

    showError(message) {
        this.loadingEl.innerHTML = `<h2 style="color: #e74c3c;">${message}</h2>`;
        this.loadingEl.classList.remove('hidden');
    }

    async copyToClipboard(text, label) {
        try {
            await navigator.clipboard.writeText(text);
            // Show brief feedback
            const originalTitle = label === 'Russian text' ? this.copyWordBtn.title : this.copyPhraseBtn.title;
            if (label === 'Russian text') {
                // Update both desktop and mobile copy word buttons
                this.copyWordBtn.textContent = '✓';
                this.copyWordBtnMobile.textContent = '✓';
                setTimeout(() => {
                    this.copyWordBtn.textContent = '📋';
                    this.copyWordBtnMobile.textContent = '📋';
                }, 1000);
            } else {
                this.copyPhraseBtn.textContent = '✓';
                setTimeout(() => {
                    this.copyPhraseBtn.textContent = '📋';
                }, 1000);
            }
        } catch (err) {
            console.error('Failed to copy:', err);
            alert('Failed to copy to clipboard');
        }
    }

    playAudio() {
        const currentVocab = this.vocabulary[this.shuffledIndices[this.currentIndex]];
        if (!currentVocab.audio) {
            return; // No audio available
        }

        // Update audio source if it's different from current
        const audioPath = `/audio/${currentVocab.audio}`;
        const currentSrc = this.audioElement.src;
        const expectedSrc = `${window.location.origin}${audioPath}`;

        // Check if we need to update the source (compare paths, not full URLs)
        if (!currentSrc || !currentSrc.includes(currentVocab.audio)) {
            this.audioElement.src = audioPath;
        }

        if (this.audioElement.paused) {
            // If paused, play the audio
            this.audioElement.play().catch(err => {
                console.error('Failed to play audio:', err);
                alert('Failed to play audio. Please check if the audio file exists.');
            });
        } else {
            // If playing, pause the audio
            this.audioElement.pause();
        }
    }

    updatePlayButtonIcon(isPlaying) {
        if (this.playAudioBtn) {
            this.playAudioBtn.textContent = isPlaying ? '⏸️' : '▶️';
            this.playAudioBtn.title = isPlaying ? 'Pause audio' : 'Play audio';
        }
    }

    async loadHardPhrasesCount() {
        try {
            const response = await fetch('/api/hard-phrases');
            if (response.ok) {
                const hardPhrases = await response.json();
                this.hardPhrasesCount = hardPhrases.length;
                if (this.hardPhrasesCountEl) {
                    this.hardPhrasesCountEl.textContent = `(${this.hardPhrasesCount})`;
                }
            }
        } catch (error) {
            console.error('Failed to load hard phrases count:', error);
            this.hardPhrasesCount = 0;
            if (this.hardPhrasesCountEl) {
                this.hardPhrasesCountEl.textContent = '(0)';
            }
        }
    }

    async saveHardPhrase() {
        if (!this.selectedMode || !this.selectedTopic) {
            return; // Not in a topic-based mode
        }

        const currentVocab = this.vocabulary[this.shuffledIndices[this.currentIndex]];
        const phrazeId = currentVocab.id;

        if (!phrazeId) {
            return; // No ID available for this phrase
        }

        try {
            const response = await fetch('/api/hard-phrases', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    mode_id: this.selectedMode.id,
                    phraze_id: phrazeId
                })
            });

            if (response.ok) {
                // Update count
                await this.loadHardPhrasesCount();
                // Show feedback
                const originalText = this.saveHardPhraseBtn.textContent;
                this.saveHardPhraseBtn.textContent = '✓ Saved';
                setTimeout(() => {
                    this.saveHardPhraseBtn.textContent = originalText;
                }, 2000);
            }
        } catch (error) {
            console.error('Failed to save hard phrase:', error);
            alert('Failed to save phrase. Please try again.');
        }
    }

    async removeHardPhrase() {
        if (!this.isHardPhrasesMode) {
            return;
        }

        const currentVocab = this.vocabulary[this.shuffledIndices[this.currentIndex]];
        const phrazeId = currentVocab.id;
        const modeId = currentVocab.mode_id;

        if (!phrazeId || !modeId) {
            return;
        }

        try {
            const params = new URLSearchParams({ mode_id: modeId });
            const response = await fetch(`/api/hard-phrases/${phrazeId}?${params}`, {
                method: 'DELETE'
            });

            if (response.ok) {
                // Remove phrase from vocabulary array
                this.vocabulary = this.vocabulary.filter(v => v.id !== phrazeId);

                // Rebuild shuffled indices for remaining vocabulary
                this.shuffledIndices = Array.from({ length: this.vocabulary.length }, (_, i) => i);
                this.shuffleArray(this.shuffledIndices);

                // Adjust current index
                if (this.currentIndex >= this.vocabulary.length) {
                    this.currentIndex = Math.max(0, this.vocabulary.length - 1);
                }

                // Update count
                await this.loadHardPhrasesCount();

                // Move to next phrase or show completion
                if (this.vocabulary.length === 0) {
                    this.showNoHardPhrases();
                } else {
                    // If we removed the last phrase, go to previous
                    if (this.currentIndex >= this.vocabulary.length) {
                        this.currentIndex = this.vocabulary.length - 1;
                    }
                    this.showCurrentWord();
                }
            }
        } catch (error) {
            console.error('Failed to remove hard phrase:', error);
            alert('Failed to remove phrase. Please try again.');
        }
    }

    async startHardPhrasesReview() {
        try {
            this.loadingEl.classList.remove('hidden');
            this.modeSelectionEl.classList.add('hidden');

            const response = await fetch('/api/hard-phrases');
            if (!response.ok) {
                throw new Error('Failed to fetch hard phrases');
            }

            const hardPhrases = await response.json();

            if (hardPhrases.length === 0) {
                this.showNoHardPhrases();
                return;
            }

            // Convert to vocabulary format
            this.vocabulary = hardPhrases.map(p => ({
                word: p.en || p.ru, // Default word (for backward compatibility)
                ru: p.ru || null,
                en: p.en || null,
                phrase: p.pl,
                id: p.id || null,
                audio: p.audio || null,
                mode_id: p.mode_id
            }));

            // Create shuffled indices
            this.shuffledIndices = Array.from({ length: this.vocabulary.length }, (_, i) => i);
            this.shuffleArray(this.shuffledIndices);

            // Reset training state
            this.currentIndex = 0;
            this.showingWord = true;
            this.isHardPhrasesMode = true;
            this.selectedMode = null;
            this.selectedTopic = null;

            // Show back button
            this.backToTopicsBtn.classList.remove('hidden');

            // Start training
            this.startApp();
        } catch (error) {
            console.error('Failed to load hard phrases:', error);
            this.showError('Failed to load hard phrases. Please try again.');
        }
    }

    showNoHardPhrases() {
        this.loadingEl.classList.add('hidden');
        this.modeSelectionEl.classList.add('hidden');
        this.appEl.classList.add('hidden');
        this.completionEl.classList.add('hidden');
        this.noHardPhrasesEl.classList.remove('hidden');
    }
}

// Initialize the app when the page loads
document.addEventListener('DOMContentLoaded', () => {
    new PolishVocabApp();
});
